# CAMSECURE PRO — Android background streaming starter

This is a native Android + WebRTC + WebSocket signaling starter.

## What it supports
- Camera owner explicitly starts sharing from the visible Android activity.
- A foreground service owns the camera/WebRTC session and displays an ongoing notification.
- The stream can continue while the app is minimized or the screen is locked, subject to Android/device power-management policies.
- The owner can stop sharing from the app or the notification.
- A browser viewer connects using a room code.

## Important
This is source code, not a signed/installable APK. Build it with Android Studio. It has not been built or device-tested in this environment.
The Node signaling server must be deployed on a public HTTPS/WSS host. Configure a TURN server for reliable connections across mobile networks. STUN-only connections are not guaranteed.
Do not start capture invisibly. The app deliberately requires the owner to press Start while the activity is visible.

## Setup
1. Install Android Studio (current stable) and JDK 17.
2. Open the `android` folder as a project.
3. In `android/app/src/main/java/com/camsecure/pro/Config.kt`, set `SIGNALING_URL` to your deployed secure WebSocket URL, e.g. `wss://your-domain.example/ws`.
4. Build and install on an Android phone (min SDK 26, target SDK 35).
5. Deploy `server/server.js` using Node 20+:
   - `cd server`
   - `npm install`
   - `PORT=3000 npm start`
   Put it behind HTTPS/WSS reverse proxy.
6. Open `viewer/index.html` from an HTTPS host, configure `SIGNALING_URL` in the file, and enter the same room code shown in the Android app.

## Android behavior
- Android 14+ requires a camera foreground-service type and CAMERA permission.
- Start is initiated while the activity is visible because camera access is subject to while-in-use restrictions.
- The persistent notification is intentionally visible while sharing.
- Battery optimization, OEM task managers, thermal limits, loss of network, or force-stop may still interrupt a session.
