package com.camsecure.pro

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*

/**
 * Foreground service scaffold.
 * The service owns camera capture so it can continue while the activity is minimized.
 * Signaling and WebRTC offer/answer events are relayed through the Socket.IO server.
 */
class CameraStreamService : Service() {
    companion object {
        const val ACTION_START = "com.camsecure.pro.START"
        const val ACTION_STOP = "com.camsecure.pro.STOP"
        const val EXTRA_ROOM = "room"
        private const val CHANNEL = "camera_sharing"
        private const val NOTIFICATION_ID = 7001
    }

    private var socket: Socket? = null
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var capturer: CameraVideoCapturer? = null
    private var textureHelper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var roomCode: String = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopStreaming(); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                roomCode = intent.getStringExtra(EXTRA_ROOM).orEmpty()
                if (roomCode.isBlank()) { stopSelf(); return START_NOT_STICKY }
                startForeground(NOTIFICATION_ID, notification("Camera sharing is active"))
                startWebRtc()
            }
        }
        return START_NOT_STICKY
    }

    private fun notification(message: String): android.app.Notification {
        createChannel()
        val stopIntent = Intent(this, CameraStreamService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("CAMSECURE PRO — Sharing camera")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "STOP SHARING", pending)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Camera sharing", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startWebRtc() {
        try {
            val init = PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions()
            PeerConnectionFactory.initialize(init)
            factory = PeerConnectionFactory.builder().createPeerConnectionFactory()

            val egl = EglBase.create()
            textureHelper = SurfaceTextureHelper.create("CameraCapture", egl.eglBaseContext)
            videoSource = factory!!.createVideoSource(false)
            capturer = createCameraCapturer()
            capturer?.initialize(textureHelper, this, videoSource!!.capturerObserver)
            capturer?.startCapture(1280, 720, 24)
            videoTrack = factory!!.createVideoTrack("camera0", videoSource)

            val options = IO.Options()
            socket = IO.socket(Config.SIGNALING_URL, options)
            socket?.on(Socket.EVENT_CONNECT) {
                socket?.emit("join-room", JSONObject().put("room", roomCode).put("role", "owner"))
            }
            socket?.on("viewer-joined") { args ->
                createPeerAndOffer()
            }
            socket?.on("answer") { args ->
                val sdp = args.firstOrNull() as? JSONObject ?: return@on
                peer?.setRemoteDescription(object : SdpObserver {
                    override fun onSetSuccess() {}
                    override fun onSetFailure(error: String?) {}
                    override fun onCreateSuccess(desc: SessionDescription?) {}
                    override fun onCreateFailure(error: String?) {}
                }, SessionDescription(SessionDescription.Type.ANSWER, sdp.optString("sdp")))
            }
            socket?.on("ice-candidate") { args ->
                val c = args.firstOrNull() as? JSONObject ?: return@on
                peer?.addIceCandidate(IceCandidate(c.optString("sdpMid"), c.optInt("sdpMLineIndex"), c.optString("candidate")))
            }
            socket?.connect()
        } catch (e: Exception) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun createCameraCapturer(): CameraVideoCapturer? {
        val enumerator = Camera2Enumerator(this)
        val names = enumerator.deviceNames
        val chosen = names.firstOrNull { enumerator.isFrontFacing(it) } ?: names.firstOrNull() ?: return null
        return enumerator.createCapturer(chosen, null)
    }

    private fun createPeerAndOffer() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        )
        peer = factory?.createPeerConnection(iceServers, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate ?: return
                socket?.emit("ice-candidate", JSONObject()
                    .put("room", roomCode).put("candidate", candidate.sdp)
                    .put("sdpMid", candidate.sdpMid).put("sdpMLineIndex", candidate.sdpMLineIndex))
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onDataChannel(channel: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
            override fun onTrack(transceiver: RtpTransceiver?) {}
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState?) {}
        })
        val track = videoTrack ?: return
        peer?.addTrack(track, listOf("camsecure-stream"))
        peer?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) return
                peer?.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        socket?.emit("offer", JSONObject().put("room", roomCode).put("sdp", desc.description))
                    }
                    override fun onSetFailure(error: String?) {}
                    override fun onCreateSuccess(d: SessionDescription?) {}
                    override fun onCreateFailure(error: String?) {}
                }, desc)
            }
            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
            override fun onCreateFailure(error: String?) {}
        }, MediaConstraints())
    }

    private fun stopStreaming() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); capturer = null
        videoTrack?.dispose(); videoTrack = null
        videoSource?.dispose(); videoSource = null
        textureHelper?.dispose(); textureHelper = null
        peer?.close(); peer?.dispose(); peer = null
        socket?.disconnect(); socket?.close(); socket = null
        factory?.dispose(); factory = null
    }

    override fun onDestroy() {
        stopStreaming()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
