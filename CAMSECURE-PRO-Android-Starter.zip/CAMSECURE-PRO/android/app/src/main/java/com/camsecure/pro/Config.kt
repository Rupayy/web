package com.camsecure.pro

object Config {
    // Replace with your deployed secure Socket.IO signaling endpoint.
    const val SIGNALING_URL = "https://YOUR-SIGNALING-DOMAIN.example"
}
