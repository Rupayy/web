package com.camsecure.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var room: EditText
    private lateinit var status: TextView
    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF080D19.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFF4F7FF.toInt())
        }
        layout.addView(label("CAMSECURE PRO", 25f))
        layout.addView(label("Consent-based background camera streaming", 14f))
        room = EditText(this).apply {
            hint = "Enter a private room code"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AAAC0.toInt())
        }
        layout.addView(room)
        val start = Button(this).apply { text = "START SHARING" }
        layout.addView(start)
        val stop = Button(this).apply { text = "STOP SHARING" }
        layout.addView(stop)
        status = label("Not sharing. Start only when you are ready.", 14f)
        layout.addView(status)
        layout.addView(label("A persistent notification remains visible while sharing. You can stop at any time.", 12f))
        setContentView(layout)

        start.setOnClickListener {
            val code = room.text.toString().trim()
            if (code.length < 4) { status.text = "Enter a room code with at least 4 characters."; return@setOnClickListener }
            val permissions = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
                status.text = "Grant the requested permissions, then press START SHARING again."
                return@setOnClickListener
            }
            val intent = Intent(this, CameraStreamService::class.java).apply {
                action = CameraStreamService.ACTION_START
                putExtra(CameraStreamService.EXTRA_ROOM, code)
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "Sharing requested. Check the persistent notification."
        }
        stop.setOnClickListener {
            startService(Intent(this, CameraStreamService::class.java).apply { action = CameraStreamService.ACTION_STOP })
            status.text = "Stop requested."
        }
    }
}
