const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

io.on("connection", socket => {
  socket.on("join-room", ({ room, role }) => {
    if (typeof room !== "string" || room.length < 4 || room.length > 80) return;
    if (!["owner", "viewer"].includes(role)) return;
    socket.data.room = room;
    socket.data.role = role;
    socket.join(room);
    if (role === "viewer") socket.to(room).emit("viewer-joined");
  });
  for (const event of ["offer", "answer", "ice-candidate"]) {
    socket.on(event, payload => {
      if (!socket.data.room || payload?.room !== socket.data.room) return;
      socket.to(socket.data.room).emit(event, payload);
    });
  }
  socket.on("disconnect", () => {
    if (socket.data.room) socket.to(socket.data.room).emit("peer-left", { role: socket.data.role });
  });
});

app.get("/", (_req, res) => res.send("CAMSECURE PRO signaling server is running."));
const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Signaling server listening on ${port}`));
